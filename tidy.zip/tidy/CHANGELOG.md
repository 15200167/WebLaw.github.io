# CHANGELOG.md

## 2.5.1 (Oct 17, 2020)

Fix typos

## 2.5.0 (Apr 1, 2020)

First release
