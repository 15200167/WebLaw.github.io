<template>
    <div class="carousel-item">
        <slot />
    </div>
</template>

<script>
export default {
  name: 'CCarouselItem'
}
</script>

